package com.example.tiger.calculator;

import java.util.Stack;
import java.util.ArrayList;
import java.util.EmptyStackException;
import java.lang.Math;

/**
 * Created by Tiger on 10/28/2017.
 */

public class SolveEquation {

    public static String returnAnswer(ArrayList<Object> results){

        Stack<Double> stak = new Stack<Double>();
        Object element;
        Double first, second;

        for(int a=0; a<results.size(); a++){
            //get the next element in results
            element = results.get(a);

            if(element instanceof Number){
                stak.push((Double)element);
            }

            else{
                if(stak.empty()){
                    throw new EmptyStackException();
                }
                second = stak.pop();
                first = stak.pop();

                if(element.equals("+")){
                    stak.push(first+second);
                }else if(element.equals("-")){
                    stak.push(first-second);
                }else if(element.equals("x") || element.equals("*")){
                    stak.push(first*second);
                }else if(element.equals("/")){
                    stak.push(first/second);
                }else if(element.equals("^")){
                    stak.push(Math.pow(first, second));
                }

            }
        }

        double a = stak.pop();
        String answer = String.valueOf(a);
        return answer;
    }
}
