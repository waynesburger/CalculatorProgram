package com.example.tiger.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.EmptyStackException;

import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.GridView;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText equation;
    Button one, two, three, four, five, six, seven, eight, nine, zero;
    Button plus, minus, times, divide, exp, dot, open, close;
    Button solve;
    Button clear;
    Button backspace;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        equation = (EditText) findViewById(R.id.input);

        one = (Button) findViewById(R.id.one);
        one.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("1");
                    }
                }
        );

        two = (Button) findViewById(R.id.two);
        two.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("2");
                    }
                }
        );

        three = (Button) findViewById(R.id.three);
        three.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("3");
                    }
                }
        );

        four = (Button) findViewById(R.id.four);
        four.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("4");
                    }
                }
        );

        five = (Button) findViewById(R.id.five);
        five.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("5");
                    }
                }
        );

        six = (Button) findViewById(R.id.six);
        six.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("6");
                    }
                }
        );

        seven = (Button) findViewById(R.id.seven);
        seven.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("7");
                    }
                }
        );

        eight = (Button) findViewById(R.id.eight);
        eight.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("8");
                    }
                }
        );

        nine = (Button) findViewById(R.id.nine);
        nine.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("9");
                    }
                }
        );

        zero = (Button) findViewById(R.id.zero);
        zero.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("0");
                    }
                }
        );

        plus = (Button) findViewById(R.id.plus);
        plus.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("+");
                    }
                }
        );

        minus = (Button) findViewById(R.id.minus);
        minus.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("-");
                    }
                }
        );

        times = (Button) findViewById(R.id.times);
        times.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("*");
                    }
                }
        );

        divide = (Button) findViewById(R.id.divide);
        divide.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("/");
                    }
                }
        );

        exp = (Button) findViewById(R.id.exp);
        exp.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("^");
                    }
                }
        );

        dot = (Button) findViewById(R.id.decimal);
        dot.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append(".");
                    }
                }
        );

        open = (Button) findViewById(R.id.open);
        open.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append("(");
                    }
                }
        );

        close = (Button) findViewById(R.id.close);
        close.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.append(")");
                    }
                }
        );

        solve = (Button) findViewById(R.id.solve);
        solve.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        ArrayList<Object> results = Conversion.toPostfix(equation.getText().toString());
                        try{
                            equation.setText(SolveEquation.returnAnswer(results));
                        }catch(EmptyStackException ese){
                            equation.setText("Bad Syntax, try again");
                        }
                    }
                }
        );

        backspace= (Button) findViewById(R.id.backspace);
        backspace.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        String editable = equation.getText().toString();
                        if(editable.length() > 0) {
                            int newLength = editable.length() - 1;
                            editable = editable.substring(0, newLength);
                            equation.setText(editable);
                        }
                    }
                }
        );

        clear = (Button) findViewById(R.id.clear);
        clear.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.setText(" ");
                    }
                }
        );

    }
}
