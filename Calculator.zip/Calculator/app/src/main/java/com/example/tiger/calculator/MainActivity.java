package com.example.tiger.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.EmptyStackException;
import android.widget.EditText;
import android.widget.Button;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    EditText equation;
    Button solve;
    Button clear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        equation = (EditText) findViewById(R.id.input);
        solve = (Button) findViewById(R.id.solve);
        clear = (Button) findViewById(R.id.clear);

        solve.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        ArrayList<Object> results = Conversion.toPostfix(equation.getText().toString());
                        try{
                            equation.setText(SolveEquation.returnAnswer(results));
                        }catch(EmptyStackException ese){
                            equation.setText("Bad Syntax, try again");
                        }
                    }
                }
        );

        clear.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        equation.setText(" ");
                    }
                }
        );

    }
}
