package com.example.tiger.calculator;

import android.widget.BaseAdapter;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.widget.Button;

/**
 * Created by Tiger on 10/29/2017.
 */

public class ButtonAdapter extends BaseAdapter {

    private Context con;
    private final String[] inputs;

    public ButtonAdapter(Context c, String[] val) {
        this.con = c;
        this.inputs = val;
    }

    @Override
    public int getCount(){ return inputs.length; }

    @Override
    public Object getItem(int position){
        return null;
    }

    @Override
    public long getItemId(int position){
        return 0;
    }

    public View getView(int position, View convertView, ViewGroup parent){

        LayoutInflater inf = (LayoutInflater) con.getSystemService(con.LAYOUT_INFLATER_SERVICE);

        View buttonGrid;

        if(convertView == null){
            buttonGrid = new View(con);
            buttonGrid = inf.inflate(R.layout.grid_layout, null);

            Button b = (Button) buttonGrid.findViewById(R.id.theButton);
            b.setText(inputs[position]);
        }else{
            buttonGrid = (View) convertView;
        }

        return buttonGrid;
    }
}

