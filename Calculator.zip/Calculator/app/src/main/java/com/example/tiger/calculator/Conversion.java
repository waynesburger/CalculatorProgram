package com.example.tiger.calculator;

import java.util.Stack;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Comparator;

/**
 * Created by Tiger on 10/28/2017.
 */

public class Conversion {

        public static ArrayList<Object> toPostfix(String inString){

            Stack<String> stck = new Stack<String>();
            ArrayList<Object> results = new ArrayList<Object>();
            StringTokenizer equation = new StringTokenizer(inString, "+-*x/%^()", true);
            String elem;
            opComparison op = new opComparison();

            while(equation.hasMoreElements()){
                elem = equation.nextToken();

                if(thisIsANumber(elem)){
                    //turn elem to a Double and insert into results
                    results.add(Double.parseDouble(elem));
                }else if(elem.equals("(")){
                    //push elem into stck
                    stck.push(elem);
                }else if(elem.equals(")")){
                    //pop everything from stck and add it to results until
                    //an opening parenthesis is reached
                    String popped;
                    while(true){
                        popped = stck.pop();
                        if(popped.equals("("))break;
                        else results.add(popped);
                    }
                }else if(elem.equals("+") || elem.equals("-") || elem.equals("*") || elem.equals("/") || elem.equals("^")){
                    if(!stck.empty()){
                        //stck.peek() lower presidence than elem: return positive number
                        //stck.peek() higher presidence than elem: return negative number
                        //stck.peek() same presidence as elem: return 0
                        while(!stck.peek().equals("(") || op.compare(elem, stck.peek()) < 0){
                            results.add(stck.pop());
                            if(stck.size() == 0){
                                break;
                            }
                        }
                    }
                    stck.push(elem);

                }
            }

            while(!stck.empty()){
                results.add(stck.pop());
            }

            return results;
        }

        public static boolean thisIsANumber(String elem){
            //determine if the string token is a number
            //return true or false
            if(elem == null) return false;

            int length = elem.length();
            if(length == 0) return false;

            int x = 0;
            if(elem.charAt(x) == '-'){
                if(length == 1) { return false; }
                else{ x += 1; }
            }

            char c;
            int dotCount = 0;
            for(; x < length; x++){
                c = elem.charAt(x);
                if(c < '0' || c > '9'){
                  if(c != '.'){
                      return false;
                  }else{
                      dotCount++;
                  }
                }
            }
            if(dotCount > 1){
                return false;
            }
            return true;
        }
}
